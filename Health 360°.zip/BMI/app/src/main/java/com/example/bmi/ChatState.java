package com.example.bmi;

public enum ChatState {
    INITIAL_GREETING,
    ASK_MAIN_CONCERN,
    ASK_DETAILS,
    PROVIDE_SOLUTION,
    OFFER_SUPPORT,
    END_CONVERSATION
}
